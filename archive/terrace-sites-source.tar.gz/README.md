# Terrace — Premier League 反波胆 demo

A responsive reverse correct-score sportsbook with 10,000 starting play credits, risk-based bet slips, a wallet, ticket history, watchlist, search, and simulated settlement. No payment gateway or exchange order execution.

## Run

Node 22.13+ is required. Install with `node scripts/install-ci.mjs`, then run `npm run dev`. Open the Local URL printed by Vinext. Build with `node /Users/yanglee/.codex/plugins/cache/openai-curated-remote/sites/1.1.2/scripts/build-site.mjs` in this host or `npm run build` elsewhere.

## Betfair Odds API

Reference: https://betfair-odds.com/docs

The server endpoint `/api/markets` fetches `GET /betfair/v1/livemap?feed=live&sports=soccer` and the equivalent prematch feed. Authentication uses the `x-portal-apikey` header. Set **BETFAIR_ODDS_API_KEY** as a secret in Sites runtime settings and redeploy. For local preview, put the key in ignored `.dev.vars` as `BETFAIR_ODDS_API_KEY=...`. Never put the key in client code, source control, or a public environment variable.

Use Data settings → Check connection & load odds. Without a key, the app stays in clearly labeled demo mode. Live API credentials were not supplied, so authenticated upstream requests have not been verified. Both feeds must be fresh; requests fail closed if either feed is stale or unavailable. Manual refresh only, a 30-second server cache, and a 30-second price expiry avoid silent stale-price betting. Refresh consumes up to two provider calls, subject to the provider account quota.

The parser requires soccer, a Premier League competition name, `CORRECT_SCORE`, numeric score runners, `layOdds > 1`, and positive `laySize`. It groups by market ID and retains market ID + runner ID + handicap for identity. Provider liquidity sizes are not used to claim real order matching; all credit orders are local simulations.

## Credit model

The amount entered is **maximum loss / liability**, not exchange lay stake. Profit is liability / (lay odds - 1), rounded down to two decimals. Placement reserves liability. A different final score returns liability + profit; a matching score loses the liability. No demo commission. Decimal stakes, insufficient funds, missing selections, and changed prices are validated.

“My bets → Simulate result” applies one chosen demo result to all open tickets on a match, once. Settled matches cannot accept further bets. Results remain simulated even with API-sourced prices: the supplied odds feed does not provide verified final results for settlement.

One localStorage record persists the wallet and ticket history in this browser. No real funds, multi-user accounting, or cross-device sync. Demo data is locally editable and not a production accounting system.

## Verify

`npx tsc --noEmit`

`node --experimental-strip-types --test lib/market.test.ts`

Covers win/loss accounting, multi-ticket settlement, duplicate settlement, rejected stakes, changed prices, and API parsing.

## Assets

Stadium photo: https://images.unsplash.com/photo-1522778119026-d647f0596c20

Barlow Condensed and DM Sans served locally from Google Fonts. Club badges are illustrative initials, not official marks.
